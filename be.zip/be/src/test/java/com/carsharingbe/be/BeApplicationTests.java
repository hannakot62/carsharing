package com.carsharingbe.be;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BeApplicationTests {

	@Test
	void contextLoads() {
	}

}
